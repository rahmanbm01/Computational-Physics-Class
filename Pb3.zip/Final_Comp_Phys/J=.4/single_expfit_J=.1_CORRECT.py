
#the comments are exactly same as 3a first data set
import numpy as np
import random
import matplotlib as mp
import matplotlib.pyplot as plt
from scipy.optimize import curve_fit

import pickle



import pandas as pd

openpcklfile_ave=open('ave.pckl', 'rb')
ave=pickle.load(openpcklfile_ave)
openpcklfile_ave.close()

openpcklfile_t=open('t.pckl', 'rb')
t=pickle.load(openpcklfile_t)
openpcklfile_t.close()



nrun=100
#t=t/nrun
#ave in averaged
ave=ave/nrun
'''
t_new=[]
ave_new=[]
index_t=0
for element_t in t:
    if index_t<=200:
       t_new.append(element_t)
    index_t=index_t+1
index_ave=0
for element_ave in ave:
    if index_ave<=200:
       ave_new.append(element_ave)
    index_ave=index_ave+1
t=np.array(t_new)
ave=np.array(ave_new)
print(len(t))
print(len(ave))
'''
'''
data = pd.read_csv (r'/Users/andyketchum/Documents/HW5/data_1.csv', header=None)   
df = pd.DataFrame(data)
#print(df.iloc[:,1:2])
x=(df.iloc[:,0:1].to_numpy())
y=(df.iloc[:,1:2].to_numpy())

x=x.flatten('F')
y=y.flatten('F')
'''


def fitfunction(t,A,taue1,B):
	return A*np.exp(-t/taue1)+B 


#fit to fitfunction
init_vals=[[5],[1000],[2]]
fits,cov=curve_fit(fitfunction,t,ave,p0=init_vals)
print(fits)

plt.scatter(t,ave)
plt.plot(t,fitfunction(t,*fits),'r-')
plt.ylabel('<E>/(J*N^2)')
plt.xlabel('n=iteration')

plt.show()


init_vals=[[100],[10000], [10]]
fits,cov=curve_fit(fitfunction,t,ave,p0=init_vals)
print(fits)

plt.scatter(t,ave)
plt.plot(t,fitfunction(t,*fits),'b-')
plt.ylabel('<E>/(J*N^2)')
plt.xlabel('n=iteration')


plt.show()

init_vals=[[10],[10000],[-5]]
fits,cov=curve_fit(fitfunction,t,ave,p0=init_vals)
print(fits)

plt.scatter(t,ave)
plt.plot(t,fitfunction(t,*fits),'y-')
plt.ylabel('<E>/(J*N^2)')
plt.xlabel('n=iteration')


plt.show()
'''

init_vals=[[-10],[10],[-20], [50]]
fits,cov=curve_fit(fitfunction,x,y,p0=init_vals)
print(fits)
plt.scatter(x,y)
plt.plot(x,fitfunction(x,*fits),'b-')
plt.ylabel('y')
plt.xlabel('x')
plt.show()

init_vals=[[-100],[-50], [-7], [-12]]
fits,cov=curve_fit(fitfunction,x,y,p0=init_vals)
print(fits)
plt.scatter(x,y)
plt.plot(x,fitfunction(x,*fits),'g-')
plt.ylabel('y')
plt.xlabel('x')
plt.show()

print('Based on the curve results: trials 1, 2 and 4 give the same parameters\
    the other trials are obviously not crrect just by looking at the graph shapes  and negative tau, ' 'Final Parameters A=0.50716837  and tau1=1.97805574, B=0.49558754 and tau2=20.27225225')
'''    
