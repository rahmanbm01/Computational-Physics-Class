#!/home/bmrahman/work/Anaconda3/bin/python
#SBATCH -p batch
#SBATCH -o myMPI.o%j    # Output and error file name (%j expands to jobID)
#SBATCH -n 4
#SBATCH -t 01:10:00
#SBATCH --mail-type=END
#SBATCH --mail-user=bmrahman@uh.edu        #your email id
import numpy as np
import math
import matplotlib
import matplotlib.pyplot as plt

from functions import get_init_energy  #compute energies
from functions import energy_difference  #compute energy differences
#these are externally defined, 

def metropolis(e,enew):  
	if(e>enew):
		return True
	else:
		if np.random.random()<math.exp((e-enew)):
			return True
		else:
			return False
N=50  #size of the lattice
nstep=5000	#steps in the simulation
printstep=100	#steps between printing
nprint=int(nstep/printstep)
nrun=100

t=np.zeros(nprint)
avm=np.zeros(nprint)
ave=np.zeros(nprint)
ave2=np.zeros(nprint)

np.random.seed(2)

J=.1  #interaction strength (with kT=1)
b=0  #magnetic field.    

pbc=True  #this flags whether to use PBCs
print('initial t is ' + str(t))
print('initial avm is ' + str(avm))
print('initial ave is ' + str(ave))
for run in range(nrun):
    print('NEW RUN '+ str(run))

    spins=[[0 for _ in range(N)] for _ in range(N)] #define the spins as all down
    m=0
    
    for i in range(N):
        print('')
        print('   row '+ str(i))
        for j in range(N):
            print('')
            print('')
            print('      col '+ str(j))
            if np.random.random()<.5:
                spins[i][j]=1  
                m+=1
               
                print('         spin is'+ str(spins[i][j]))
                print('         m is ' + str(m))
               
            else:
                spins[i][j]=-1
                m-=1
               
                print('         spin is'+ str(spins[i][j]))
                print('         m is ' + str(m))
    e=get_init_energy(spins,J,b,N,pbc)
    print(spins)
    print(' initial energy is'+str(e))

    for step in range(nstep):
            print('   STEP is '+ str(step))
            print('   This means flipping of a random spin')
            
            
            s1=np.random.randint(0,N)
            s2=np.random.randint(0,N)
            #randomly choose a spin to flip.  		
            

            enew=e+energy_difference(s1,s2,spins,J,b,N,pbc)
            #compute the energy
            if(metropolis(e,enew)):
            #with the metropolis criterion, choose to flip the spin
                spins[s1][s2]=-spins[s1][s2]
                if spins[s1][s2]>0:
                    m+=2
                else:
                    m-=2
                #update the magnetization due tot he flip
                e=enew
                print('      enew is'+str(enew))
                #update the energy due to the flip
            if step%printstep==0:
                print('      step%printstep is '+ str(step%printstep))

                t[int(step/printstep)]=step
                  #every printstep, we want to print data
                print('      int(step/printstep)'+ str(int(step/printstep)))
                print('')
                print('      abs(m)/N/N'+str(abs(m)/N/N))
                print('      OLD avm[int(step/printstep)'+str(avm[int(step/printstep)]))
                print('      e/J/N/N'+str(e/J/N/N))
                print('      OLD ave[int(step/printstep)]'+str(ave[int(step/printstep)]))
                print('')
                print('')
                print('')
                print('')
                avm[int(step/printstep)]+=abs(m)/N/N
                print('      NEW avm[int(step/printstep)'+str(avm[int(step/printstep)]))
                
                ave[int(step/printstep)]+=e/J/N/N
                ave2[int(step/printstep)]+=((e)/J/N/N)**2
                print('      NEW ave[int(step/printstep)]'+str(ave[int(step/printstep)]))
                print('      avm is'+str(avm))
                print('      ave is'+str(ave))
                print('      flipped spins'+ str(spins))
                
s=np.transpose(spins)
print(s)
'''
for i in range(N):
	y=[j for j,e in enumerate(s[i]) if e==1]
	x=[i for _ in range(len(y))]
	plt.scatter(x,y,color='b')
'''
import pickle

writepcklfile=open('ave.pckl', 'wb')
pickle.dump(ave, writepcklfile)
writepcklfile.close()

writepcklfile=open('ave_squared.pckl', 'wb')
pickle.dump(ave2, writepcklfile)
writepcklfile.close()

writepcklfile=open('avm.pckl', 'wb')
pickle.dump(avm, writepcklfile)
writepcklfile.close()

writepcklfile=open('t.pckl', 'wb')
pickle.dump(t, writepcklfile)
writepcklfile.close()
'''
writepcklfile=open('kf_dict_final.pckl', 'wb')
pickle.dump(kf_dict_final, writepcklfile)
writepcklfile.close()

writepcklfile=open('kr_dict_final.pckl', 'wb')
pickle.dump(kr_dict_final, writepcklfile)
writepcklfile.close()

writepcklfile=open('K_dict_final.pckl', 'wb')
pickle.dump(K_dict_final, writepcklfile)
writepcklfile.close()

ax1=plt.axes()
ax1.set_aspect('equal')
plt.title('spins')
plt.show()


plt.plot(t/nrun,avm/nrun)
plt.xlabel('iteration')
plt.ylabel('<m>')
plt.title('magnetization')
plt.title('')
plt.show()


plt.plot(t/nrun,ave/nrun)
plt.xlabel('iteration')
plt.ylabel('<E>/JN^2')
plt.title('energy')
plt.show()
'''
