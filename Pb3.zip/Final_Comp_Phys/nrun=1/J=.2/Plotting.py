#Opening pickle file as Molecule3 which is a dictionary
import pickle
import numpy as np
import matplotlib.pyplot as plt
from gekko import GEKKO
m = GEKKO()


nrun=1


openpcklfile_ave=open('ave.pckl', 'rb')
ave=pickle.load(openpcklfile_ave)
openpcklfile_ave.close()
print('(ave/nrun)')
print(ave/nrun)
#print(Concentrations[0])
#Time=Concentrations[0]
openpcklfile_avm=open('avm.pckl', 'rb')
avm=pickle.load(openpcklfile_avm)
openpcklfile_avm.close()

openpcklfile_t=open('t.pckl', 'rb')
t=pickle.load(openpcklfile_t)
openpcklfile_t.close()
'''
openpcklfile_ave_squared=open('ave_squared.pckl', 'rb')
ave_squared=pickle.load(openpcklfile_ave_squared)
openpcklfile_ave_squared.close()

#(avg_energy)_squared=(ave/nrun)**2
fluctuations=ave_squared/nrun-(ave/nrun)**2
ax1=plt.axes()
print('ave_squared/nrun')
print(ave_squared/nrun)
print('(ave/nrun)**2')
print((ave/nrun)**2)
print('fluctuations')
print(fluctuations)
'''
'''
ax1.set_aspect('equal')
plt.title('spins')
plt.show()
'''
'''
plt.plot(t,avm/nrun)
plt.xlabel('iteration')
plt.ylabel('<m>')
plt.title('magnetization')
plt.title('')
plt.savefig('J=.1,avg_magnetization.png')

plt.show()
'''
plt.plot(t,ave/nrun)
plt.xlabel('iteration')
plt.ylabel('<E>/JN^2')
plt.title('avg_energy')
plt.savefig('J=.2,avg_energy.png')

plt.show()
'''
plt.plot(t,ave_squared/nrun)
plt.xlabel('iteration')
plt.ylabel('<E^2>/(JN^2)^2')
plt.title('avg(energy_squared)')
plt.savefig('J=.1,avg(energy_squared).png')

plt.show()

plt.plot(t,fluctuations)
plt.xlabel('iteration')
plt.ylabel('(<E^2>-<E>^2)/(JN^2)^2')
plt.title('fluctuations')
plt.savefig('J=.1,fluctuations.png')
plt.show()
'''
